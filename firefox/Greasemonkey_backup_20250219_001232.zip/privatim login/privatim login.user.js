// ==UserScript==
// @name         privatim login
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Automatically log in to the specified site with predefined credentials.
// @author       c
// @match        http://127.0.0.1/login
// @match        http://0.0.0.0/login
// @match        http://127.0.0.1/consultations/add
// ==/UserScript==
(function () {
    'use strict';

    // Login functionality
    if (window.location.href.includes('/login')) {
        const observer = new MutationObserver((mutations, obs) => {
            const emailInput = document.querySelector('#username');
            const passwordInput = document.querySelector('#password');
            const signInButton = document.querySelector('.form-signin button[type="submit"]');
            if (emailInput && passwordInput && signInButton) {
                emailInput.value = 'admin@example.org';
                passwordInput.value = 'test';
                signInButton.click();
                obs.disconnect();
            }
        });
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    // Form filling functionality
    if (window.location.href.includes('consultations/add')) {

        window.addEventListener('load', () => {
            // Function to generate lorem ipsum text
            function loremIpsum(words) {
                const loremText = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";
                return loremText.split(' ').slice(0, words).join(' ');
            }

            // Fill out the form fields
            document.getElementById('title').value = loremIpsum(5);

            // For TipTap editors
            const editors = ['description', 'recommendation', 'evaluation_result', 'decision'];
            editors.forEach(id => {
                const editor = document.querySelector(`#${id}-editor .ProseMirror`);
                if (editor) {
                    editor.innerHTML = `<p>${loremIpsum(20)}</p>`;
                    // Trigger input event to ensure TipTap updates its internal state
                    editor.dispatchEvent(new Event('input', {bubbles: true}));
                }
            });

            // Set a random status
            const statusSelect = document.getElementById('status');
            if (statusSelect) {
                const randomIndex = Math.floor(Math.random() * statusSelect.options.length);
                statusSelect.selectedIndex = randomIndex;
            }

            // Select random cantons
            const cantonSelect = document.getElementById('secondary_tags');
            if (cantonSelect && cantonSelect.tomselect) {
                const allOptions = cantonSelect.tomselect.options;
                const optionKeys = Object.keys(allOptions);
                const randomCount = Math.floor(Math.random() * 5) + 1; // Select 1 to 5 cantons
                const selectedOptions = [];
                for (let i = 0; i < randomCount; i++) {
                    const randomIndex = Math.floor(Math.random() * optionKeys.length);
                    selectedOptions.push(optionKeys[randomIndex]);
                }
                cantonSelect.tomselect.setValue(selectedOptions);
            }

            const pdfBase64 = "JVBERi0xLjQKJcOkw7zDtsOfCjIgMCBvYmoKPDwvTGVuZ3RoIDMgMCBSL0ZpbHRlci9GbGF0ZURlY29kZT4+CnN0cmVhbQp4nCWKwQrCQAxE7/mK/MBuk213YyEErLSH3oTcxJvoWS/+vpvKwMwwbyhzwS+8kQ59XrA41JalosiUGf2Bw8bYX/68KbGNSoVGE+2WuChNVC31bIHEmDSGPznZHCA1pTnw+ahL1IvdfYfV4Qo/Yf0cbwplbmRzdHJlYW0KZW5kb2JqCgozIDAgb2JqCjExMwplbmRvYmoKCjUgMCBvYmoKPDwvTGVuZ3RoIDYgMCBSL0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGgxIDk4MjA+PgpzdHJlYW0KeJzlOHtwG+Wdv29XsmTLtiRbkuUoslbeOIljy/IzxCGJFT9kJ3Zi+QVSgFhrSbYEtiQk2SE8DtPyyBlSwqOUQOZIOcpQypV1Q6+B44q5wl07HC1t6fRom2tujg5zU3KkNOU6lMj3+z6tHCcEOndz/91Ku/t7v79vV8qkZiNQDPPAgyc0IyWrKy1lAPDPAKQsNJcRtg+ar0T4NAD3k8nk1Mxj37n2HIDqBQDNC1PTBydffeaZFEBxFKBIFY1I4XPN45sALNNoY3MUCSPZgxrEn0J8XXQmc5PAf28j4t9HvHU6EZK+abpTh/gniK+dkW5KOlWdHECFFXEhLs1E/vhX3wsjvgVAl04m0pkwHFoGqH6O8pOpSHLgsYnXEcd4+SNII/ihRzGCBRTneJW6QKMtLNIVw//HQ30YzNCn3g56SLLrRQf/HFTCUYDl9yl24ZodWP74/zIKbe72KDwNL8BheAeuUxhe8EEMZpGy+ngVfoxUevhgHzwLC59h9jk4ifycXBDup5lc9vDBV+AE/NNFXnwwA7dgLN+Gd0gT/ABHJQEfEi3cAa+j1Q+RtudyprhSvEwycHIV9ZfwOHcv7ObeReQo5XBuzgCvwTGyHy1nMM/DKxlv+5TRe+A2vI5AFOYQZod6+ye/gMLl32NWt8Fu+ALshOlVGi+TJ/gi7N8oPIE1fZXR3Hmmpo+/nvtbjjv/ECIPwBSeEsHcucP8zs+o0P/44MeghNTyNVB4OS7XCvrsx1zz8jl+HRTB2PLZPG25f/n3vJSNq8ZVa9XbVW98no+CB1QzqA3Lv8nekg2r96qfxm49A+DpvWZfwD82OjI85Bvcu2egf/euvl5vT3dX505Px47t267c2r7lis1tTY3uBlf9xg3ra9aJ1U6H1WQ06EtLdEWFWk2BWsVzBOoFmQR7ZL5GMHolsUeU+lz1Qo812u2q7xG9QVmQBBlvqvViXx8jiZIsBAV5Pd6kVeSg7EHJyUskPTlJz4okMQjbYBt1IQrym92icJLsG/IjfLhbDAjyGQbvYbBqPUNKEHE6UYNFRaMVemTvXHShJ4gxkkVdUZfYFSly1cNikQ5BHULyRjG5SDbuIAzgNvZsXeRAW0LdYqY9Ulj2Dfl7um1OZ8BVv0suFbsZC7qYSbmgS9Ywk0KMhg73Cov1Swv3nTTARLCuOCyGpWv9Mi+h7gLfs7Bwj2ysk2vFbrn25netmHlErhe7e+Q6arV/eMVP/wWXRFbXGERh4Q+A6Yhn3r+YIimUghrDH4CCMtclk2G/kx42L9Z6YcErCt6F4IJ0cnl+QhQM4sJicfFCsgfLDT4/mji5/NK9Ntl7X0A2BKNka0BJ3TvcL5cPXeOXuRqvEJWQgt8O0bnF5jSuyPg+iw1YFiwOVtjppGW496QHJhCR54f8OVyACdu3wOOuC8hckHKW8hzzGOXM5zkr6kERe9s/4l+QVTW7wmIPVvxeSZ6fwOm6njZGNMilH9mc4kKZUWh3B5isgFHtCscEWb0ei4RaqxVwbqjKgoEhpR/lbmds6GC9sUxoF9EMtdMj9gSV71zUigYELHRfXW4QRv2ypxsBj6R0rGex0Y0aUhAbFutmzZTdYlI2iZ0r3aVh9cRG/ExFUZNNXTIEQ4qW7O5h60roWQh250KgtsQh/4vQsnx6sVWwnWiBVgh0U2FLF07Z+p4Ff3hSdgRtYVx3k4Lf5pQ9AexwQPRHAnTssEK1p21sOAJsVkb9/SNi/9A+/xYlkByDmlPV9FxiRvTbcmZwAGVtjVbwczY+gIIGJAheBMTObXiVNTVaPA1YcEalg9u5TfATG+SlMQy5VuiJdCtyFL/IqJqOU1df3loBRdFOV5/NGXDmDlc9h2xBcYwaWlrUvjwLtylkaHE+u/oYidbSSode8IsRMSBGBdnj89PcaHlYlZVisJorvRq9CFtVLCwTOJGdR2gxZW+dbXVx5V6Gr6B9l7B35dnCglbsH1mgxkXFIGDku2SgI+zZYrSxvYAuaBH3XsGAS5ot6IVFj4cu5uhWakTcFV4QR/zbmDTuJ7fZbqa+yqCf9I92uupxa+tcFMmhoUUPOTSyz/+iAd8LD436v8URrivYGVhchzz/iwI+NBiVo1RKpIhAEWppGBEtk7e96AGYZ1wVIzA8dJIAo2nzNAKhk1yOZsg5Ws8ceYBDjirH8eSlVUjT5mjzjMaORaAl8xSpPVpPoaeYK+Fsi4SSvoWUl/A9tpDAiWJSQmyLqDXMyCfJ/GKhx5aTmEcJTy7CQ2MXXI/t858oxqezjV3RUSc9cFysUWw2PlZ6hDAdlFsD0YVggC42sGBr8EtkIu7ANok7MJCCYrlIjHTKOrGT0jsovSNHL6B0DY4osRBUn8fe+2RCJ+AavxOXpLDmB7YFwxnaqQBuKguG37iwYh34DvCs+kmwkc2efymzWHibraK8SGVfa7FV2nyBSjOYyk2+AF+u15T6AjoNsdmJyk7O2cnf2cmddpKxk7Cd1NkV+g3v2snbdvKanbxgJw8zCWT3r9L5BqNfw3RMjP5Gno62Ru2kO0/f+ltm6Ck7ObLKVaudrGMSYCfcWTs5bSdv2clxO5m3k6SdeOxEsBODncgMNTC56/C4MX+Mpy4c+69TjjzzchzoaKkDK16M0GLtoFdjGaloN7a0GFuaGsvFtivaWje3NFeYxQ3rxeoCO2kxi8YKs7Ptin978smvfXlPZ5OrurGj9eOP38iq7uX9TRs63zpd/uYt5uRjx0Y/+cjpcjmxD7bl9/lT+OZvgS97xqGsRKUqLCussKrLLeW+gMaiV+FIDwdKDJbiQl+g2HzcSk5byZKVGKwErKQdEY+VNFqJwHDZSpJWEmREhFF6Pk9BgQspX0gVs1yVZIuSZTtmaWRpElNL8xXGDW1OmtmGUiJWVxLESPvxW6e/RFoOZP9T2/tSx9mbSBUpfs7BvVfp+uSxStfAhnZi4iYrXUB/BdbirBnwt08hPOlJqvGdr8AXwDdVNa/GATO/rSOv6cgLOvKUjjysI3fqSEZHwjqyTkdMOqLSkfZzTOKIjnBJHQnqiE9HPDqypCOyjhxnqEFHQEfOMhTlVotd1Gia9vjqLuMBHfkGY95NjTWsgzRjkvhqtvL4ceL1VrpclWrOSteNafl9zqW6A/vV69lQVFqqKef5CquqWFeMOWl0ehOAcSgAlidYAzqsxM3qnsp7aVkpcVl7czOtsLp6fZtRbOvA8aEDZLJgwc2lhOwNjt9yW6Tj5z+/snHriHinKTXFPeTa8LOfjZ6/fWenYafVQV/twYfz4+Vfx9+Va+GwZ18lIfo1WrPebK+qBF9AX+mo5Ir5ysrisjKLL1BmKFYPBYotS1VEriLHq8iRKjJfRZJVJFhFfFUEqsgOvHmqSGMVEaqIoYqcZXIodNHU5AsHrGzQbnWP77+uThmc/OSYTVWkpXkzTUasXm/EtSIYzaS6wOxsXU9U22+f2vxwY+PXrvrlGz98hcSyX4kmyIPXknfKFo76ynRbHA3vE/VHH2Ynh8mxZ546cZTOURn+0nkP14oN3vZECnRlJcXqNeWmSpXNVmnmy9VGDf6eWGu3e6Rwn8pusnPr7K32bnvYfqf9Kftr9rft79oLKX0dEinpBSS+az9nL2pXIY2KPYzUgnVMmjLU9pPLSyfszj5692zSV/ThLsOBvdHOFfKVprISfYkvoC5eU64qtOj1tgKVrlDnC3CFZsgtpBba77KK9hxMsETj19XV3YglvDGFxapQFll+qdXQwdMRNn+FdJGZNbbcrZDw72Wvuu2d7B3Zb86QtuzZBHn2tm+/dQcZns7+kbS5XK4Ksie7aHa5DORR8gCOqy37ITHg3Zx9NttAazeKc/tTnJONEPC0OjWmNSVggtpNJU6+oqLKF7BVGHiMXcNb5jeR5CYS3ER8m4iwiTy/iYxvIoObSH4NXdgVse/tF1rO9ooCbPSGtpYKnOG2Vjdp4C7aIc0mS0UVz/108W+8X290NfXf9A9HA5Frm79+ZOpx96a21NDYnr0P7esQifa+I/ay977Y/fTNrXZnd8h76/2ON2fcvu72vWuaG7quYnPfh3N/I/8qzkINzHg6jNqaGpVQXFyp4vEnZnVR9VDAajYa1+ISMDqMuASMRtAWWTQqzNEMZl8ADPMbyPgG4tlAEMCGpJRxprmVtSvzDO2rtn2jkmWzxcw2Q0zW2LqDdJC2VsxOT8S2zURTimNPh578+LEHZrPZ8tTi73Ydf/Rw7+7wSPWWJwl88e7x+7tDzfyrf/GF83dVuvaniHX/LTt51UPSte7ZN8VslUq9Py47rPl981HsmQmGPC6jRkOKi82WAiMYDUauVG3kOZPBgBNo0GuKi3D7KTKPW4jDQjwWkksnt63RhFpaMB9jftvJrU5xQ3WBxriy21XsIC3co3Vbm/+y+avZzgMHSFnhtje38a9n4zbL+U66A/JCpWu2+Vpge/perP9ejM0CQc82o1pnUVsqrFo9PqO0BouJNw0FeAs+kHasPJ3wgXXWSt7KP5SQ/ryVjNPNcWVn3r+yF7fUrTyEcF3g/iEY2SAZ6SAJuT2S39v03L7sFf/xzj3Hr6gbyWTP/fU3HpxuX1dLfvfb847sx0+7s9G3v+2kseKezP8Gnz92eMlzEEymypLS0sLKwiqHfY0vYAcTIhWVGHmFuZzj1GrjcEBtOO4gpx1kyUEMDgIOfNA6yBEHSTpI0EF8DuJxkEYHERzEwdjIms9zkfUW05Qd5Pgq+uoH0SVvIjfm8jbmn8At+cdR+4XdgZg02CFl9rBlrWL1qu4Rr6bvOx0335rK3nDb0/u/eHs2fOA+0sx/FG2o3fale84/QvvH7X/Ofr581bMMx6vy6CdHD98yrt/2B3Dk/hf8fvdbP7zwrw92+T18S6R/GnIKCfU0zmwPXL0iRC75q6ikoJ2+XUKHCsDGtUMtVcW7iT8MPqSV8XYYRbgPZWrxvhdpJqb5GtlMjuHnXW4f90c+yP9EJajm1BzzUILrIRcDBwZwAw4i9z3+H4Fn3CoSX4njqpWYCEpepcAcaGBSgXncN2YUWIUyhxRYjV4eVeAC0MPXFFgDN8MLCqwFE2lQ4EIoJZ0KXETixKfAOljLfXfl3+8G7hcKXAJtvFaBS2ENv51Gr6L/2j3HX63ABAQVr8AclKpEBeZhs6pJgVUoM6XAalijukeBC6BK9VUF1sA51SsKrIWN6hMKXAhr1b9U4CLuV+r/UmAdbNH+VIGL4dpCnQKXwPWFeV+l0Fr44+7YVCwTuzkSFsJSRhJCieTBVGwqmhE2hmqF5samRqE3kZiajghdiVQykZIysUS8oajrUrFmYRhN9EmZemFXPNQwEJuI5GSFkUgqNjkcmZqdllI706FIPBxJCS7hUolL8asiqTRFmhuaGtouMC+VjaUFScikpHBkRkrdICQmL45DSEWmYulMJIXEWFwYaxhpEHxSJhLPCFI8LIyuKA5OTsZCEUYMRVIZCYUTmShGev1sKpYOx0LUW7phJYFV1RjJROYiwh4pk4mkE/FOKY2+MLLRWDyRrhcORGOhqHBASgvhSDo2FUfmxEHhYh0BuRLmEo8n5tDkXKQe455MRdLRWHxKSNOUFW0hE5UyNOmZSCYVC0nT0wexZTNJ1JrAHh2IZaLoeCaSFvZGDgjDiRkp/mxDLhSszSTWVIjNJFOJORajKx1KRSJxdCaFpYnYdCyD1qJSSgphxbBssVCaVQQLISSluKtnNpVIRjDSq3sHLghigLlqphPTc+iZSscjkTD1iGHPRaZRCR1PJxI30HwmEykMNJyJulZFPpmIZ1A1IUjhMCaO1UqEZmdon7DMmXxwUiiVQF5yWsqglZl0QzSTSW51uw8cONAgKa0JYWca0LL783iZg8mI0o8UtTIzPYDtj9PWzbL+0iRGdg0Ig0msjxeDExSBeiE/mU0NTYoLLGMsmUk3pGPTDYnUlHvQOwDdEIMpPDN43gwRCIOAp4S4hFAIEpCEg5BiUlGkCvgyF8JNUYBmaIQmPAXoRakE8qdRX4AuhFOoRa8Ss5uAODRAEeN8vrVmhIaVKPqYdj1Cu1A/hBYGUG8CuavtCjDCKDHcZqnmFMxiHBJSdkIatSIoE2YSArjw/HM2/hz/KgalVzjNGFcTnm2X1fxzdmNoSWCVzjAOjXSGRX8D0hKo93n1EFAuwrqXRk6EYWFmldoeQ4kRJuVjmrQSGeYtzqRGL+NxED1Oon6IdTIvGWK26UTkLCcQjio1vR7rnWIRhJlePrc0ev50By4/GyMsujnmcw+jUzzNeJ2Ip5W8cjUbZVEkkEprcQAjoX6jDJZYPcNMm85YXNGcwKkTPtePoOhKSl/izMecEiXVqVfqPcmuaeY3jj4EFl+uyxf7FlidJFb1XKdnkJthsiGkT+PnoLLKZrAqOV8Tyjo6wFZlVMl4htkVYC/eD7CpSLC+xZ3VrMcXqpKbm0llTgWmm0Q4wbLI19HFekMzibBIKSSxlT+BGtPMdy62KJsOifU2ovQ6wzLI1yusZEqjTjKKC3rYXND1HlFqejXuEwOXtZir4OrZpD2ZZvGmV9mOs2jDKznmqk2lphVPuYyn2X50w0p/Jtm85SoaZtZcn1HzSVabjOI1wSIK4yfX8dxsJVB3lvUjt55y05z5VOUkVt+Eopdku1JGiWWGrY8om8AkbMUXSzdGRz8NbA5Xr5qQsmYalJjd/2s9GleSVXD1+kitxDKDMQ4oqz++supmV63ffCdGcA8aYPtFUpkfr1I54RILdNVcumc2sT3z4ixy0xhDPMPiSbNaNrAcppA/iB4G6Dt07hfCXRjSZY7FQt/OCRIBQqJkCsrxR1IQ9pJxGCM7YTvx4N2DvE68dyFO7w1kO8yj3Hak70B8G9KvxL3TgdcOPAfxvB9PFZ45iUaUcOPdreAuxOtR40d4Jeyk1A6k0vtuxPvw3qvcvUjvwXuPgu9CHO8QJBr6Bzm7vkJUnhPk9Hnyo/NEOE9u/xPx/YnMf3jkQ+53Z2sdz5995Sw3+MH4B89/wDd+QPQfEC2cMZzxnQmeSZ45fqagSP8+KYbfEuO/n97i+PX2U2P/uv1XY3AKMzvVeMp3av6UfEp9ivBjv+ItDsOSsNS4lFyaX3pr6fTS2SXt/HePfJf7+5fdDv3Ljpc5x4nBE7ef4IPPEP0zjmc43+PBx7kjx4j+mOOY+xj/2NEGx9HeKsdXHtngOP3I2Uc4+sfVIyVG78tkkAzAdqzh3hP8suP5nWayB9PS49WBpxvPQTwTeN6PJ/7mQXEHnm4y4NnCj3+Z6B60PVj34C0P3vugOnn3/N1H7ubn7zpyF/f83CtzXNpX60jE6xzx3k2OyhbrmKaFHytAN/Tvsl0TNRu9wXGPYxyFrtnX6NjXW+sobykbU2PCKhTU8w6+gx/kE/z9/Cu8Rjvsq3IM4Xnad9bHeXyFxV79oGPQPcifXD7tifQ70dru5O753fwub62jr3eLQ9/r6HX3/qj3170f9BaM95In8Ot93vuKl/d4a91ej7fK6V3bZxuztJjHjEQ/ZmjRj3EEG90CY279sp7T68f1t+t5PXQAN28hanKSHFkcHamr6z+pWR7ul7W+a2RySK4ZoVfP0D654JAMY/uu8S8S8qXAXYcPQ6e9X24e8ctBe6BfDiPgocA8Agb7ogU6A+l0po4dpK4O4Vm8Qt1sHRL3p3NUWOFDXZqkcYtKMyVSRwVyOMFrHeUhgeoR1N6fBnqhzLqcEtVOK+aYcu7CAOv+/wYmeoioCmVuZHN0cmVhbQplbmRvYmoKCjYgMCBvYmoKNTgxNAplbmRvYmoKCjcgMCBvYmoKPDwvVHlwZS9Gb250RGVzY3JpcHRvci9Gb250TmFtZS9CQUFBQUErTGliZXJhdGlvblNlcmlmCi9GbGFncyA0Ci9Gb250QkJveFstNTQzIC0zMDMgMTI3NyA5ODFdL0l0YWxpY0FuZ2xlIDAKL0FzY2VudCAwCi9EZXNjZW50IDAKL0NhcEhlaWdodCA5ODEKL1N0ZW1WIDgwCi9Gb250RmlsZTIgNSAwIFIKPj4KZW5kb2JqCgo4IDAgb2JqCjw8L0xlbmd0aCAyNzkvRmlsdGVyL0ZsYXRlRGVjb2RlPj4Kc3RyZWFtCnicXZHPboQgEMbvPAXH7WEjuruuTYzJ1mYTD/2T2j4AwmhJKhDEg29fBrZt0gPkNzPfZ8aPrO0eO6189uqM6MHTUWnpYDGrE0AHmJQmeUGlEv5WxVvM3JIsePtt8TB3ejR1TbK3MFu82+juIs0AdyR7cRKc0hPdfbR9qPvV2i+YQXvKSNNQCWP4zhO3z3yGLLr2nQxj5bd9sPwJ3jcLtIh1nlYRRsJiuQDH9QSkZqyh9fXaENDy3yz8QrQMo/jkLkjzIGWsLJvAReTzCfmQ+i3yMXLBkE9Jc0Qukybqz6lfIVeJD8j3SZMjX1K/QH5I/ahpE1dx4dtmuDpm+xMJFatzIY74ADEHTEBp+H0jayy64vkG9tOHOgplbmRzdHJlYW0KZW5kb2JqCgo5IDAgb2JqCjw8L1R5cGUvRm9udC9TdWJ0eXBlL1RydWVUeXBlL0Jhc2VGb250L0JBQUFBQStMaWJlcmF0aW9uU2VyaWYKL0ZpcnN0Q2hhciAwCi9MYXN0Q2hhciAxMgovV2lkdGhzWzc3NyAzMzMgNTAwIDI3NyAyNTAgMjc3IDQ0MyA1MDAgMzg5IDQ0MyAzMzMgNDQzIDUwMCBdCi9Gb250RGVzY3JpcHRvciA3IDAgUgovVG9Vbmljb2RlIDggMCBSCj4+CmVuZG9iagoKMTAgMCBvYmoKPDwvRjEgOSAwIFIKPj4KZW5kb2JqCgoxMSAwIG9iago8PC9Gb250IDEwIDAgUgovUHJvY1NldFsvUERGL1RleHRdCj4+CmVuZG9iagoKMSAwIG9iago8PC9UeXBlL1BhZ2UvUGFyZW50IDQgMCBSL1Jlc291cmNlcyAxMSAwIFIvTWVkaWFCb3hbMCAwIDU5NSA4NDJdL1JvdGF0ZSAwCi9Hcm91cDw8L1MvVHJhbnNwYXJlbmN5L0NTL0RldmljZVJHQi9JIHRydWU+Pi9Db250ZW50cyAyIDAgUj4+CmVuZG9iagoKNCAwIG9iago8PC9UeXBlL1BhZ2VzCi9SZXNvdXJjZXMgMTEgMCBSCi9NZWRpYUJveFsgMCAwIDU5NSA4NDIgXQovS2lkc1sgMSAwIFIgXQovQ291bnQgMT4+CmVuZG9iagoKMTIgMCBvYmoKPDwvVHlwZS9DYXRhbG9nL1BhZ2VzIDQgMCBSCi9WaWV3ZXJQcmVmZXJlbmNlczw8L0Rpc3BsYXlEb2NUaXRsZSB0cnVlCj4+Ci9MYW5nKGRlLUNIKQo+PgplbmRvYmoKCjEzIDAgb2JqCjw8L1RpdGxlPEZFRkYwMDY2MDA3NTAwNkMwMDZDMDA1RjAwNzQwMDY1MDA3ODAwNzQwMDVGMDA3MzAwNjUwMDYxMDA3MjAwNjMwMDY4MDAyRTAwNkYwMDY0MDA3ND4KL0NyZWF0b3I8RkVGRjAwNEMwMDY5MDA2MjAwNzIwMDY1MDA0RjAwNjYwMDY2MDA2OTAwNjMwMDY1MDAyMDAwMzcwMDJFMDAzMzAwMkUwMDM3MDAyRTAwMzI+Ci9Qcm9kdWNlcjxGRUZGMDA0QzAwNjkwMDYyMDA3MjAwNjUwMDRGMDA2NjAwNjYwMDY5MDA2MzAwNjUwMDIwMDAzNzAwMkUwMDMzMDAyRTAwMzcwMDJFMDAzMj4KL0NyZWF0aW9uRGF0ZShEOjIwMjQwNzA0MDMxOTQyKzAyJzAwJyk+PgplbmRvYmoKCnhyZWYKMCAxNAowMDAwMDAwMDAwIDY1NTM1IGYgCjAwMDAwMDY5NzUgMDAwMDAgbiAKMDAwMDAwMDAxOSAwMDAwMCBuIAowMDAwMDAwMjAzIDAwMDAwIG4gCjAwMDAwMDcxMjggMDAwMDAgbiAKMDAwMDAwMDIyMyAwMDAwMCBuIAowMDAwMDA2MTIxIDAwMDAwIG4gCjAwMDAwMDYxNDIgMDAwMDAgbiAKMDAwMDAwNjMzMiAwMDAwMCBuIAowMDAwMDA2NjgwIDAwMDAwIG4gCjAwMDAwMDY4ODggMDAwMDAgbiAKMDAwMDAwNjkyMCAwMDAwMCBuIAowMDAwMDA3MjI3IDAwMDAwIG4gCjAwMDAwMDczMzMgMDAwMDAgbiAKdHJhaWxlcgo8PC9TaXplIDE0L1Jvb3QgMTIgMCBSCi9JbmZvIDEzIDAgUgovSUQgWyA8NDRGNUU3MEU4RTA4RTZENDlGODVCNDAxRjM0QUM1QkI+Cjw0NEY1RTcwRThFMDhFNkQ0OUY4NUI0MDFGMzRBQzVCQj4gXQovRG9jQ2hlY2tzdW0gL0FENkI4ODVFNDgyMzhDM0NEODYxREUyQTZCNjY1MEI4Cj4+CnN0YXJ0eHJlZgo3NjY5CiUlRU9GCg==";

            const fileInput = document.getElementById('files');


// File upload functionality
            try {

                if (fileInput) {


                    // Convert base64 to blob
                    const byteCharacters = atob(pdfBase64);
                    const byteNumbers = new Array(byteCharacters.length);
                    for (let i = 0; i < byteCharacters.length; i++) {
                        byteNumbers[i] = byteCharacters.charCodeAt(i);
                    }
                    const byteArray = new Uint8Array(byteNumbers);
                    const blob = new Blob([byteArray], {type: 'application/pdf'});


                    // Create a File object
                    const file = new File([blob], 'sample.pdf', {type: 'application/pdf'});


                    // Create a DataTransfer object and add the file
                    const dataTransfer = new DataTransfer();
                    dataTransfer.items.add(file);


                    // Set the file input's files
                    fileInput.files = dataTransfer.files;


                    // Dispatch a change event to trigger any listeners
                    const event = new Event('change', {bubbles: true});
                    fileInput.dispatchEvent(event);


                } else {
                    console.error('File input element not found');
                }
            } catch (error) {
                console.error('Error in file upload process:', error);
            }

        });
    }
})();
