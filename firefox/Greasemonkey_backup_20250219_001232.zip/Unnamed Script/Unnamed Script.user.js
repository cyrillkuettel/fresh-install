// ==UserScript==
// @description  Fills out the Waermepumpe form automatically
// @match        *://127.0.0.1/*foerdergesuch-waermepumpe*
// @match        *://localhost/*foerdergesuch-waermepumpe*
// @match        https://www.meggen.ch/form/foerdergesuch-waermepumpe-ab-2024

// ==/UserScript==

(function() {
    'use strict';
  console.log('running');

        const formData = {
            'einreicherin_vorname': 'Max',
            'einreicherin_name': 'Mustermann',
            'einreicherin_strasse': 'Musterstrasse 123',
            'einreicherin_plz_ort': '6045 Meggen',
            'einreicherin_telefon': '041 123 45 67',
            'einreicherin_e_mail': 'max.mustermann@example.com',
            'auszahlungskonto_iban': 'CH93 0076 2011 6238 5295 7',
            'auszahlungskonto_lautend_auf': 'Max Mustermann',
            'objekt_adresse': 'Musterstrasse 123, 6045 Meggen',
            'objekt_grundstucknummer': '1234',
            'anlage_installateur_anbieter': 'Muster AG',
            'anlage_typ_fabrikat': 'EcoHeat Pro 2000',
            'anlage_leistung_in_kw': '12',
            'anlage_inbetriebnahme': '01.01.2024'
        };


   for (const [id, value] of Object.entries(formData)) {
       const element = document.getElementById(id);
       if (!element) {
           console.warn(`Form field ${id} not found`);
           return; // Exit early if we are not on that page
       }
       element.value = value;
   }



    // Create and add the fill button
    const button = document.createElement('button');
    button.textContent = 'Formular automatisch ausfüllen';
    button.style.cssText = 'position: fixed; top: 20px; right: 20px; z-index: 9999; ' +
                          'background-color: orange; color: white; border: none; ' +
                          'padding: 10px 20px; border-radius: 5px; cursor: pointer; ' +
                          'font-size: 16px; font-weight: bold;';

    document.body.appendChild(button);

    // Function to fill form
    function fillForm() {
        // Sample data for required fields


        // Fill text inputs
        Object.entries(formData).forEach(([id, value]) => {
            const element = document.getElementById(id);
            if (element) {
                element.value = value;
            }
        });

        // Trigger change events
        Object.keys(formData).forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                const event = new Event('change', { bubbles: true });
                element.dispatchEvent(event);
            }
        });
    }

    // Add click handler
    button.addEventListener('click', fillForm);
})();