// ==UserScript==
// @name     Minimal Reddit js
// @version  1
// @grant    none
// @match https://old.reddit.com/*
// ==/UserScript==


(function () {
    'use strict';

    if (document.readyState !== 'loading') {
        console.log('document is already ready, just execute code here');
        main();
    } else {
        document.addEventListener('DOMContentLoaded', function () {
            console.log('document was not ready, place code here');
            main();
        });
    }
  

    function trueTypeOf (obj) {
      return Object.prototype.toString.call(obj).slice(8, -1).toLowerCase();
    }


    function main() {


        // when clicked on this
        const dropdown = document.querySelector('.dropdown.lightdrop');

        // remove the default onclick Function
        dropdown.removeAttribute("onclick");

        // add the class to this
        const actualDropdown = document.querySelector('.drop-choices.lightdrop');


        if (dropdown == null || actualDropdown == null) {
            console.error('Could not querySelector the dropdown or actualDropdown');
            return;
        }

        // makes the dropdown appear
        dropdown.addEventListener("click", function () {
            console.log(`clicked. Adding inuse to ${actualDropdown}`);
            actualDropdown.classList.add("inuse");
        });


        const baseUrl = window.location.href.split('?')[0];

        const links = ["hour", "week", "month", "year", "all"];


        // delete the crappy banners
        actualDropdown.innerHTML = '';
        actualDropdown.style.position = '';

        // build simple links
        let counter = 0;
        for (const item of links) {


            const timeValue = item;
            const link = document.createElement('a');
            link.href = `${baseUrl}?sort=top&t=${timeValue}`;
            link.className = 'choice';
            if (links[counter] === 'all') {
                link.innerText = links[counter];

            } else {
                link.innerText = 'past ' + links[counter];

            }

            actualDropdown.appendChild(link);

            counter++;
        }

        // remove anyoning stuff
        const schabernack = document.querySelector('.premium-banner-outer');
        schabernack.style.display = "None";

        const infobar_schabernack = document.querySelector('.infobar.listingsignupbar');
        infobar_schabernack.style.display = "None";

// fix images


        const expandbuttons = document.querySelectorAll('div.expando-button');


        if (expandbuttons) {

            [...expandbuttons].forEach((b) => {
                b.addEventListener("click", function () {
                    b.classList.remove("collabsed");
                    b.classList.add("expanded");

                    const closestDivToExpand = b.closest('.expando[style*="display: none;"]');
                    console.log(closestDivToExpand);

                    closestDivToExpand.style.display = 'block';


                });
            });


        } else {
            console.error("expandbuttons = document.querySelectorAll(div.expando-button) Failed");

        }

        

        console.log("starting to add event listeners");
        const expand = document.querySelectorAll('a.expand');
        [...expand].forEach((e) => {
            e.addEventListener("click", function () {

                console.log(`clicked on expand ${e} `);

                e.classList.remove("collapsed");
                e.classList.add("noncollapsed");
            });
        });

        //if clicked, toggle between these two: collapsed noncollapsed


    } // main


})();
