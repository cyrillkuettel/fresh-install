// ==UserScript==
// @name         ASVZ Auto Load More
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Automatically clicks "Mehr laden" button when it becomes visible
// @author       Your name
// @match        https://asvz.ch/426-sportfahrplan
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    
    let lastClickTime = 0;
    const COOLDOWN_MS = 1000; // 1 second cooldown between clicks

    // Create intersection observer to detect when buttons enter viewport
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const button = entry.target;
                const now = Date.now();
                
                if (now - lastClickTime < COOLDOWN_MS) {
                    return; // Still in cooldown
                }

                if (button.textContent.includes('Mehr laden')) {
                    console.log('Load more button visible, clicking...');
                    button.click();
                    lastClickTime = now;
                }
            }
        });
    }, {
        // Configure observer options
        root: null, // use viewport
        rootMargin: '50px', // start loading slightly before button comes into view
        threshold: 0.5 // trigger when button is 50% visible
    });

    // Function to start observing new buttons
    function observeNewButton(button) {
        if (button.textContent.includes('Mehr laden')) {
            observer.observe(button);
        }
    }

    // Watch for new buttons being added to the page
    const mutationObserver = new MutationObserver((mutations) => {
        mutations.forEach(mutation => {
            mutation.addedNodes.forEach(node => {
                if (node.nodeType === 1) { // Check if it's an element node
                    // Check the node itself if it's a button
                    if (node.tagName === 'BUTTON') {
                        observeNewButton(node);
                    }
                    // Check any buttons within the added node
                    node.querySelectorAll('button').forEach(observeNewButton);
                }
            });
        });
    });

    // Start observing the document for new buttons
    mutationObserver.observe(document.body, {
        childList: true,
        subtree: true
    });

    // Also observe any existing buttons
    document.querySelectorAll('button').forEach(observeNewButton);
})();